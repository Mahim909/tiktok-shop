# TikTok Shop (com.tiktok.shop) - Android APK Build

এই প্রজেক্টটি **Capacitor** এবং **GitHub Actions** দিয়ে সম্পূর্ণ কনফিগার করা হয়েছে। আপনার কাছে কোনো **কম্পিউটার (PC)** বা **USB ক্যাবল** না থাকলেও সরাসরি মোবাইল দিয়ে GitHub-এ আপলোড করেই **APK ফাইল** বানিয়ে নিতে পারবেন!

---

## 📱 অ্যাপ ইনফরমেশন (App Details)
- **App Name:** `TikTok Shop`
- **Package Name:** `com.tiktok.shop`
- **Version:** `1.0`
- **Features:** লাইভ TikTok কয়েন টপ-আপ, bKash / Nagad / Crypto পেমেন্ট, অটো কুপন, অফলাইন প্রোটেকশন স্ক্রিন, এবং WhatsApp ইন্টিগ্রেশন।

---

## 🚀 মোবাইল দিয়ে কিভাবে APK বানাবেন ও ডাউনলোড করবেন:

### ধাপ ১: GitHub-এ নতুন Repository তৈরি করুন
1. আপনার মোবাইলের ব্রাউজার (Chrome) দিয়ে [github.com](https://github.com)-এ যান।
2. **"+" (New repository)** আইকনে চাপ দিন।
3. Repository-এর নাম দিন যেমন: `tiktok-shop-app`।
4. **Public** অথবা **Private** সিলেক্ট করে **Create repository**-তে ক্লিক করুন।

### ধাপ ২: কোড আপলোড করুন (Upload Zip / Files)
1. এই প্রজেক্টের জিপ ফাইলটি ডাউনলোড করে নিন।
2. GitHub Repository পেজে **"uploading an existing file"** অথবা **Add file > Upload files**-এ ট্যাপ করুন।
3. জিপের ভেতরের ফাইলগুলো (অথবা পুরো প্রজেক্ট) আপলোড করে নিচে **Commit changes**-এ চাপ দিন।

### ধাপ ৩: স্বয়ংক্রিয় APK তৈরি (GitHub Actions)
1. ফাইল আপলোড হওয়ার সাথে সাথে GitHub Actions স্বয়ংক্রিয়ভাবে APK তৈরি শুরু করে দেবে!
2. আপনার Repository-র ওপরের মেন্যু থেকে **"Actions"** ট্যাবে যান।
3. **"Build TikTok Shop Android APK"** নামের ওয়ার্কফ্লো দেখতে পাবেন (হলুদ রঙের ঘড়ির মতো আইকন চলা শুরু করবে, আনুমানিক ২-৩ মিনিট সময় নেবে)।
4. বিল্ড শেষ হলে সবুজ টিক চিহ্ন (✔️) আসবে।
5. সেই বিল্ডটিতে ক্লিক করে নিচের **Artifacts** সেকশনে যান।
6. সেখানে **`TikTok-Shop-APK`** নামের ফাইল পাবেন—ক্লিক করলেই সরাসরি আপনার ফোনে **`TikTok-Shop-v1.0.apk`** ডাউনলোড হয়ে যাবে!
7. এছাড়াও যদি `main` বা `master` ব্রাঞ্চে পুশ করেন, তাহলে সরাসরি **Releases** সেকশনে সরাসরি ইন্সটলযোগ্য `.apk` ফাইল পাবেন।

---

## ⚙️ লোকাল বিল্ড কমান্ড (যদি ভবিষ্যতে পিসিতে চালাতে চান):
```bash
npm install
npm run build
npx cap sync android
cd android && ./gradlew assembleDebug
```
APK লোকেশন:
`android/app/build/outputs/apk/debug/app-debug.apk`
