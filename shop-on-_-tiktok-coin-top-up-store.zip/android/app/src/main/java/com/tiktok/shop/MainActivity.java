package com.tiktok.shop;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
