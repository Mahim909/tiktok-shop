export interface CoinPackage {
  id: string;
  name: string;
  coins: number;
  price: number; // in BDT
  isPopular?: boolean;
}

export interface Review {
  id: string;
  name: string;
  email?: string;
  rating: number;
  comment: string;
  timestamp: number;
}

export type PaymentGatewayId = 'bkash' | 'nagad' | 'crypto';

export interface PaymentGateway {
  id: PaymentGatewayId;
  name: string;
  label: string;
  numberOrAddress: string;
  instruction: string;
  trxPlaceholder: string;
  logo: string;
}

export interface CouponData {
  code: string;
  discount?: number;
  amount?: number;
}
