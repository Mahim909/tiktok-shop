import React from 'react';

interface TikTokCoinIconProps {
  className?: string;
}

export const TikTokCoinIcon: React.FC<TikTokCoinIconProps> = ({ className = "w-6 h-6" }) => {
  return (
    <svg
      viewBox="0 0 48 48"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      <circle cx="24" cy="24" r="22" fill="url(#coin_grad_outer)" stroke="#D97706" strokeWidth="1.5" />
      <circle cx="24" cy="24" r="18" fill="url(#coin_grad_inner)" stroke="#F59E0B" strokeWidth="1" />
      {/* 3D Inner ring */}
      <circle cx="24" cy="24" r="15" fill="none" stroke="#FDE68A" strokeDasharray="2 2" strokeWidth="1" />
      
      {/* TikTok Note Icon in Coin Center */}
      <path
        d="M26.5 14C27.2 16.2 29 17.8 31.5 18V21.5C29.4 21.5 27.6 20.6 26.5 19.3V27.5C26.5 31.1 23.6 34 20 34C16.4 34 13.5 31.1 13.5 27.5C13.5 23.9 16.4 21 20 21C20.5 21 21 21.07 21.5 21.2V24.8C21.05 24.6 20.55 24.5 20 24.5C18.35 24.5 17 25.85 17 27.5C17 29.15 18.35 30.5 20 30.5C21.65 30.5 23 29.15 23 27.5V14H26.5Z"
        fill="#FFFFFF"
        stroke="#78350F"
        strokeWidth="0.8"
      />
      <circle cx="20" cy="27.5" r="2" fill="#FEF08A" />

      {/* Lighting highlight reflection */}
      <path
        d="M12 18C15 12 24 10 32 14"
        stroke="#FFFFFF"
        strokeWidth="1.5"
        strokeLinecap="round"
        opacity="0.6"
      />

      <defs>
        <radialGradient id="coin_grad_outer" cx="30%" cy="30%" r="70%">
          <stop offset="0%" stopColor="#FDE68A" />
          <stop offset="60%" stopColor="#F59E0B" />
          <stop offset="100%" stopColor="#D97706" />
        </radialGradient>
        <radialGradient id="coin_grad_inner" cx="40%" cy="35%" r="65%">
          <stop offset="0%" stopColor="#FEF3C7" />
          <stop offset="70%" stopColor="#FBBF24" />
          <stop offset="100%" stopColor="#D97706" />
        </radialGradient>
      </defs>
    </svg>
  );
};
