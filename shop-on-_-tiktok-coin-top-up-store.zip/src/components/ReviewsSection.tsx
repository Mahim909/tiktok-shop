import React, { useState } from 'react';
import { Star, Edit3, ChevronDown, ChevronUp, CheckCircle } from 'lucide-react';
import { Review } from '../types';

interface ReviewsSectionProps {
  reviews: Review[];
  isLoading: boolean;
  onOpenReviewModal: () => void;
}

export const ReviewsSection: React.FC<ReviewsSectionProps> = ({
  reviews,
  isLoading,
  onOpenReviewModal,
}) => {
  const [showAll, setShowAll] = useState(false);

  // Compute stats
  const total = reviews.length;
  const counts = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 };
  let sum = 0;

  reviews.forEach((r) => {
    const star = Math.min(5, Math.max(1, Math.round(r.rating || 5))) as 1 | 2 | 3 | 4 | 5;
    counts[star] = (counts[star] || 0) + 1;
    sum += Number(r.rating) || 5;
  });

  const avgScore = total > 0 ? (sum / total).toFixed(1) : '5.0';

  const avatarColors = [
    'bg-orange-500',
    'bg-emerald-600',
    'bg-blue-600',
    'bg-purple-600',
    'bg-rose-500',
    'bg-indigo-600',
    'bg-amber-600',
    'bg-teal-600',
  ];

  const getAvatarColor = (name: string) => {
    let hash = 0;
    for (let i = 0; i < name.length; i++) {
      hash = name.charCodeAt(i) + ((hash << 5) - hash);
    }
    return avatarColors[Math.abs(hash) % avatarColors.length];
  };

  const displayedReviews = showAll ? reviews : reviews.slice(0, 5);

  return (
    <section className="bg-white border border-slate-200/80 rounded-3xl p-5 sm:p-6 shadow-xs space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-slate-100 pb-4">
        <div>
          <h2 className="text-sm sm:text-base font-black tracking-wide text-slate-900 uppercase flex items-center gap-2">
            <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
            <span>Ratings and reviews</span>
          </h2>
        </div>
        <button
          type="button"
          onClick={onOpenReviewModal}
          className="text-orange-600 hover:text-orange-700 font-bold text-xs flex items-center gap-1.5 bg-orange-50/80 hover:bg-orange-100/80 px-3 py-2 rounded-xl border border-orange-200/80 transition cursor-pointer"
        >
          <Edit3 className="w-3.5 h-3.5" />
          <span>Rate this app</span>
        </button>
      </div>

      {/* Google Play Store Rating Overview Box */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-6 items-center">
        {/* Left: Overall Score & Stars */}
        <div className="md:col-span-2 flex flex-col items-center justify-center text-center md:border-r border-slate-100 pr-0 md:pr-4">
          <div className="flex items-baseline gap-1">
            <span className="text-5xl font-black text-slate-900 tabular-nums">
              {avgScore}
            </span>
            <span className="text-slate-400 text-base font-bold">/5</span>
          </div>
          <div className="flex items-center gap-0.5 my-1.5 text-amber-400">
            {[1, 2, 3, 4, 5].map((star) => (
              <Star
                key={star}
                className={`w-4 h-4 ${
                  star <= Math.round(Number(avgScore))
                    ? 'fill-amber-400 text-amber-400'
                    : 'text-slate-200 fill-slate-100'
                }`}
              />
            ))}
          </div>
          <p className="text-[11px] font-semibold text-slate-400">
            {total} verified reviews
          </p>
        </div>

        {/* Right: Breakdown Progress Bars */}
        <div className="md:col-span-3 space-y-1.5 text-xs text-slate-500 font-semibold">
          {([5, 4, 3, 2, 1] as const).map((starNum) => {
            const count = counts[starNum] || 0;
            const percentage = total > 0 ? Math.round((count / total) * 100) : 0;
            return (
              <div key={starNum} className="flex items-center gap-2">
                <span className="w-3 text-right">{starNum}</span>
                <Star className="w-2.5 h-2.5 fill-amber-400 text-amber-400 shrink-0" />
                <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden border border-slate-200/60">
                  <div
                    className="bg-orange-500 h-2 rounded-full transition-all duration-500"
                    style={{ width: `${percentage}%` }}
                  />
                </div>
                <span className="text-[10px] text-slate-400 w-7 text-right tabular-nums">
                  {percentage}%
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Reviews List */}
      <div className="space-y-4 pt-2">
        {isLoading && reviews.length === 0 ? (
          <div className="text-center py-6 text-slate-400 text-xs">
            Loading customer reviews...
          </div>
        ) : displayedReviews.length === 0 ? (
          <div className="text-center py-6 text-slate-400 text-xs">
            No reviews yet. Be the first to share your experience!
          </div>
        ) : (
          displayedReviews.map((rev) => {
            const initial = (rev.name || 'User').trim().charAt(0).toUpperCase();
            const avatarBg = getAvatarColor(rev.name || 'User');
            const dateStr = rev.timestamp
              ? new Date(rev.timestamp).toLocaleDateString('en-US', {
                  year: 'numeric',
                  month: 'short',
                  day: 'numeric',
                })
              : 'Recently';

            return (
              <div
                key={rev.id}
                className="border-b border-slate-100 pb-4 last:border-b-0 space-y-1.5"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div
                      className={`w-8 h-8 rounded-full ${avatarBg} text-white font-bold flex items-center justify-center text-xs shadow-2xs shrink-0`}
                    >
                      {initial}
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <h4 className="text-xs font-bold text-slate-900">{rev.name}</h4>
                        <span className="text-[9px] bg-emerald-50 text-emerald-700 border border-emerald-200/60 font-bold px-1.5 py-0.5 rounded-full flex items-center gap-0.5">
                          <CheckCircle className="w-2.5 h-2.5 text-emerald-600" />
                          Verified User
                        </span>
                      </div>
                      <div className="flex items-center gap-1 mt-0.5">
                        <div className="flex items-center text-amber-400">
                          {[1, 2, 3, 4, 5].map((s) => (
                            <Star
                              key={s}
                              className={`w-2.5 h-2.5 ${
                                s <= rev.rating
                                  ? 'fill-amber-400 text-amber-400'
                                  : 'text-slate-200 fill-slate-100'
                              }`}
                            />
                          ))}
                        </div>
                        <span className="text-[10px] text-slate-400 font-medium ml-1">
                          {dateStr}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed pl-10.5 pt-0.5">
                  {rev.comment}
                </p>
              </div>
            );
          })
        )}
      </div>

      {/* Read More / Show Less Toggle */}
      {reviews.length > 5 && (
        <div className="text-center pt-2">
          <button
            type="button"
            onClick={() => setShowAll((prev) => !prev)}
            className="bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs px-5 py-2.5 rounded-xl border border-slate-200/80 transition flex items-center justify-center gap-1.5 mx-auto cursor-pointer"
          >
            {showAll ? (
              <>
                <span>Show Less</span>
                <ChevronUp className="w-3.5 h-3.5" />
              </>
            ) : (
              <>
                <span>Read More Reviews ({reviews.length - 5} more)</span>
                <ChevronDown className="w-3.5 h-3.5" />
              </>
            )}
          </button>
        </div>
      )}
    </section>
  );
};
