import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Wallet, Copy, Check, MessageCircle, AlertCircle } from 'lucide-react';
import { PaymentGatewayId } from '../types';
import { PAYMENT_GATEWAYS, USD_RATE } from '../data/constants';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  payableAmount: number;
  selectedGateway: PaymentGatewayId;
  onSelectGateway: (method: PaymentGatewayId) => void;
  trxId: string;
  onTrxIdChange: (val: string) => void;
  trxError: string | null;
  onConfirmPayment: (e: React.FormEvent) => void;
  onShowToast: (msg: string) => void;
}

export const PaymentModal: React.FC<PaymentModalProps> = ({
  isOpen,
  onClose,
  payableAmount,
  selectedGateway,
  onSelectGateway,
  trxId,
  onTrxIdChange,
  trxError,
  onConfirmPayment,
  onShowToast,
}) => {
  const [hasCopied, setHasCopied] = useState(false);

  if (!isOpen) return null;

  const currentGateway = PAYMENT_GATEWAYS[selectedGateway];
  const payableUsd = (payableAmount / USD_RATE).toFixed(2);

  const handleCopy = () => {
    navigator.clipboard.writeText(currentGateway.numberOrAddress);
    setHasCopied(true);
    onShowToast(`${currentGateway.name} copied to clipboard!`);
    setTimeout(() => setHasCopied(false), 2000);
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-md flex items-center justify-center p-4 z-[100] overflow-y-auto">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          transition={{ duration: 0.2, ease: "easeOut" }}
          className="bg-white border border-slate-100 w-full max-w-md rounded-3xl p-6 relative shadow-2xl space-y-4 my-8"
        >
          {/* Close button */}
          <button
            type="button"
            onClick={onClose}
            className="absolute top-5 right-5 w-8 h-8 bg-slate-100 hover:bg-slate-200 text-slate-500 rounded-full flex items-center justify-center transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>

          {/* Modal Title */}
          <div className="flex items-center space-x-2.5">
            <div className="w-10 h-10 bg-orange-100 text-orange-600 rounded-xl flex items-center justify-center">
              <Wallet className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-extrabold text-slate-900">Select Payment Method</h2>
              <p className="text-[11px] text-slate-500 font-medium">
                Total Payable:{' '}
                <span className="font-extrabold text-emerald-600">
                  ৳ {payableAmount.toLocaleString()} (${payableUsd})
                </span>
              </p>
            </div>
          </div>

          <div className="space-y-4">
            {/* Payment Method Selector Grid */}
            <div className="grid grid-cols-3 gap-2">
              {/* bKash */}
              <button
                type="button"
                onClick={() => onSelectGateway('bkash')}
                className={`rounded-2xl p-3 text-center flex flex-col items-center justify-center transition border-2 cursor-pointer ${
                  selectedGateway === 'bkash'
                    ? 'border-orange-500 bg-orange-50/80 shadow-xs'
                    : 'border-slate-200 hover:border-slate-300 bg-white'
                }`}
              >
                <div className="w-8 h-8 flex items-center justify-center mb-1">
                  <span className="text-xs font-black text-pink-600 bg-pink-50 px-1.5 py-0.5 rounded border border-pink-200">
                    bKash
                  </span>
                </div>
                <span className="text-[10px] text-slate-700 font-bold">bKash</span>
              </button>

              {/* Nagad */}
              <button
                type="button"
                onClick={() => onSelectGateway('nagad')}
                className={`rounded-2xl p-3 text-center flex flex-col items-center justify-center transition border-2 cursor-pointer ${
                  selectedGateway === 'nagad'
                    ? 'border-orange-500 bg-orange-50/80 shadow-xs'
                    : 'border-slate-200 hover:border-slate-300 bg-white'
                }`}
              >
                <div className="w-8 h-8 flex items-center justify-center mb-1">
                  <span className="text-xs font-black text-orange-600 bg-orange-50 px-1.5 py-0.5 rounded border border-orange-200">
                    Nagad
                  </span>
                </div>
                <span className="text-[10px] text-slate-700 font-bold">Nagad</span>
              </button>

              {/* Crypto */}
              <button
                type="button"
                onClick={() => onSelectGateway('crypto')}
                className={`rounded-2xl p-3 text-center flex flex-col items-center justify-center transition border-2 cursor-pointer ${
                  selectedGateway === 'crypto'
                    ? 'border-orange-500 bg-orange-50/80 shadow-xs'
                    : 'border-slate-200 hover:border-slate-300 bg-white'
                }`}
              >
                <div className="w-8 h-8 flex items-center justify-center mb-1">
                  <span className="text-xs font-black text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200">
                    USDT
                  </span>
                </div>
                <span className="text-[10px] text-slate-700 font-bold">USDT (TRC20)</span>
              </button>
            </div>

            {/* Instruction and Target Address Card */}
            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200/80 text-xs space-y-2.5">
              <p className="text-slate-500 font-semibold text-[11px]">
                {currentGateway.instruction}
              </p>
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 bg-white p-2.5 rounded-xl border border-slate-200/80">
                <div className="min-w-0 pr-1">
                  <span className="font-extrabold text-slate-800 text-[11px] uppercase block">
                    {currentGateway.label}
                  </span>
                  <span className="font-mono font-bold text-xs text-slate-900 break-all select-all">
                    {currentGateway.numberOrAddress}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={handleCopy}
                  className="bg-orange-50 hover:bg-orange-100 text-orange-600 font-mono font-bold text-xs px-3 py-1.5 rounded-xl border border-orange-200/80 flex items-center justify-center gap-1.5 shrink-0 transition cursor-pointer self-start sm:self-center"
                >
                  {hasCopied ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                      <span className="text-emerald-700">Copied</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5 text-orange-600" />
                      <span>Copy</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Form for TrxID */}
            <form onSubmit={onConfirmPayment} className="space-y-4">
              <div>
                <label htmlFor="trxInput" className="text-xs font-bold text-slate-700 mb-1.5 block">
                  {selectedGateway === 'crypto' ? 'Transaction Hash / Order ID' : 'Transaction ID (TrxID)'}{' '}
                  <span className="text-red-500">*</span>
                </label>
                <input
                  id="trxInput"
                  type="text"
                  required
                  value={trxId}
                  onChange={(e) => onTrxIdChange(e.target.value)}
                  placeholder={currentGateway.trxPlaceholder}
                  className={`w-full bg-slate-50 border rounded-xl p-3 text-xs sm:text-sm font-medium text-slate-900 focus:outline-hidden focus:ring-2 transition shadow-2xs ${
                    trxError
                      ? 'border-red-400 focus:ring-red-500/20'
                      : 'border-slate-200 focus:ring-orange-500/20 focus:border-orange-500'
                  }`}
                />
                {trxError && (
                  <motion.p
                    initial={{ opacity: 0, y: -4 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="text-[11px] font-bold text-red-500 mt-1 flex items-center gap-1"
                  >
                    <AlertCircle className="w-3.5 h-3.5" />
                    <span>{trxError}</span>
                  </motion.p>
                )}
              </div>

              <motion.button
                type="submit"
                whileHover={{ scale: 1.01 }}
                whileTap={{ scale: 0.98 }}
                className="w-full bg-gradient-to-r from-orange-500 via-amber-500 to-orange-500 hover:from-orange-600 hover:to-amber-600 text-white font-extrabold py-3.5 rounded-xl text-xs sm:text-sm tracking-wider shadow-lg shadow-orange-500/20 flex items-center justify-center gap-2 transition cursor-pointer"
              >
                <MessageCircle className="w-4 h-4" />
                <span>CONFIRM VIA WHATSAPP</span>
              </motion.button>
            </form>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
