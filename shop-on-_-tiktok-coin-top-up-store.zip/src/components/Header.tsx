import React from 'react';
import { ShoppingBag, Zap, ShieldCheck } from 'lucide-react';

export const Header: React.FC = () => {
  return (
    <header className="bg-white/90 backdrop-blur-md border-b border-slate-200/80 sticky top-0 z-40 px-4 py-3.5 shadow-xs">
      <div className="max-w-4xl mx-auto flex justify-between items-center">
        {/* Brand Zone */}
        <a href="#" className="flex items-center gap-2.5 text-2xl font-black tracking-wider uppercase text-slate-900 group">
          <div className="w-10 h-10 bg-gradient-to-tr from-orange-500 via-amber-500 to-orange-600 rounded-xl flex items-center justify-center text-white shadow-md shadow-orange-500/20 group-hover:scale-105 transition-transform duration-200">
            <ShoppingBag className="w-5 h-5" />
          </div>
          <span className="bg-gradient-to-r from-orange-600 via-amber-500 to-orange-500 bg-clip-text text-transparent">
            SHOP-ON
          </span>
        </a>

        {/* Live Service Indicator */}
        <div className="flex items-center gap-2">
          <span className="bg-emerald-50 text-emerald-700 text-xs font-bold px-3 py-1.5 rounded-full border border-emerald-200/80 flex items-center gap-1.5 shadow-2xs">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span className="hidden sm:inline">Instant Service</span>
            <span className="sm:hidden">Active</span>
          </span>
          <a
            href="https://wa.me/8801301492171"
            target="_blank"
            rel="noopener noreferrer"
            className="text-xs font-semibold text-slate-600 hover:text-orange-600 px-2.5 py-1.5 rounded-lg hover:bg-slate-100 transition flex items-center gap-1"
          >
            <Zap className="w-3.5 h-3.5 text-amber-500" />
            <span className="hidden md:inline">24/7 Helpline</span>
          </a>
        </div>
      </div>
    </header>
  );
};
