import React from 'react';
import { motion } from 'motion/react';
import { Lock, ShieldCheck } from 'lucide-react';

interface VerificationOverlayProps {
  isOpen: boolean;
  progress: number;
  stepText: string;
}

export const VerificationOverlay: React.FC<VerificationOverlayProps> = ({
  isOpen,
  progress,
  stepText,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-slate-950/75 backdrop-blur-md flex flex-col items-center justify-center z-[150] p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white p-7 rounded-3xl shadow-2xl flex flex-col items-center max-w-xs w-full text-center relative border border-slate-100"
      >
        <div className="relative flex items-center justify-center mb-5">
          {/* Animated spinning outer ring */}
          <div className="w-16 h-16 rounded-full border-4 border-slate-100 border-t-orange-500 animate-spin" />
          <div className="absolute text-orange-500 text-lg flex items-center justify-center">
            <Lock className="w-6 h-6 animate-pulse" />
          </div>
        </div>

        <p className="text-slate-900 font-black text-sm sm:text-base tracking-wide mb-1">
          Verifying Payment...
        </p>
        <p className="text-slate-500 text-[11px] font-semibold min-h-[18px]">
          {stepText}
        </p>

        {/* Progress Bar */}
        <div className="w-full bg-slate-100 h-2.5 rounded-full mt-4 overflow-hidden border border-slate-200/80 p-0.5">
          <motion.div
            className="bg-gradient-to-r from-orange-500 via-amber-500 to-emerald-500 h-full rounded-full"
            style={{ width: `${progress}%` }}
            transition={{ ease: "easeOut" }}
          />
        </div>

        <div className="flex justify-between items-center w-full mt-2.5 text-[10px] text-slate-400 font-bold">
          <span className="flex items-center gap-1">
            <ShieldCheck className="w-3 h-3 text-emerald-500" />
            SSL 256-Bit
          </span>
          <span className="font-mono text-slate-600">{progress}%</span>
        </div>
      </motion.div>
    </div>
  );
};
