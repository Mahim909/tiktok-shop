import React from 'react';
import { Headphones, MessageCircle, Mail, ArrowRight } from 'lucide-react';
import { WHATSAPP_NUMBER, SUPPORT_EMAIL } from '../data/constants';

export const SupportSection: React.FC = () => {
  return (
    <section className="bg-white border border-slate-200/80 rounded-3xl p-5 sm:p-6 shadow-xs space-y-4">
      <div className="border-b border-slate-100 pb-3">
        <h2 className="text-sm sm:text-base font-black text-slate-900 uppercase flex items-center gap-2">
          <Headphones className="w-5 h-5 text-orange-500" />
          <span>Need Help? Contact Support</span>
        </h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
        {/* WhatsApp Card */}
        <a
          href={`https://wa.me/${WHATSAPP_NUMBER}`}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center justify-between p-3.5 bg-emerald-50/80 hover:bg-emerald-100/90 border border-emerald-200/90 rounded-2xl transition-all shadow-2xs group cursor-pointer"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-emerald-500 text-white rounded-xl flex items-center justify-center shadow-md shadow-emerald-500/20 group-hover:scale-105 transition-transform">
              <MessageCircle className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-black text-slate-800">WhatsApp Support</h4>
              <p className="text-[11px] font-mono text-emerald-700 font-bold">
                +880 1301-492171
              </p>
            </div>
          </div>
          <span className="text-xs font-bold bg-emerald-600 group-hover:bg-emerald-700 text-white px-3 py-1.5 rounded-xl flex items-center gap-1 shadow-2xs">
            Chat <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
          </span>
        </a>

        {/* Email Card */}
        <a
          href={`mailto:${SUPPORT_EMAIL}`}
          className="flex items-center justify-between p-3.5 bg-orange-50/80 hover:bg-orange-100/90 border border-orange-200/90 rounded-2xl transition-all shadow-2xs group cursor-pointer"
        >
          <div className="flex items-center gap-3 min-w-0 pr-2">
            <div className="w-10 h-10 bg-orange-500 text-white rounded-xl flex items-center justify-center shadow-md shadow-orange-500/20 group-hover:scale-105 transition-transform shrink-0">
              <Mail className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <h4 className="text-xs font-black text-slate-800">Email Support</h4>
              <p className="text-[11px] font-mono text-orange-700 font-bold truncate">
                {SUPPORT_EMAIL}
              </p>
            </div>
          </div>
          <span className="text-xs font-bold bg-orange-600 group-hover:bg-orange-700 text-white px-3 py-1.5 rounded-xl flex items-center gap-1 shadow-2xs shrink-0">
            Mail <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
          </span>
        </a>
      </div>
    </section>
  );
};
