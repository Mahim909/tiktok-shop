import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Star, Loader2, Send } from 'lucide-react';

interface ReviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (review: { name: string; email: string; rating: number; comment: string }) => Promise<void>;
  isSubmitting: boolean;
}

export const ReviewModal: React.FC<ReviewModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
  isSubmitting,
}) => {
  const [rating, setRating] = useState(5);
  const [hoverRating, setHoverRating] = useState<number | null>(null);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [comment, setComment] = useState('');

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !comment.trim()) return;

    await onSubmit({
      name: name.trim(),
      email: email.trim(),
      rating,
      comment: comment.trim(),
    });

    // Reset fields on successful call
    setName('');
    setEmail('');
    setComment('');
    setRating(5);
  };

  const currentDisplayRating = hoverRating !== null ? hoverRating : rating;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-md flex items-center justify-center p-4 z-[110] overflow-y-auto">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          transition={{ duration: 0.2 }}
          className="bg-white border border-slate-100 w-full max-w-md rounded-3xl p-6 relative shadow-2xl space-y-4 my-8"
        >
          {/* Close Button */}
          <button
            type="button"
            onClick={onClose}
            className="absolute top-5 right-5 w-8 h-8 bg-slate-100 hover:bg-slate-200 text-slate-500 rounded-full flex items-center justify-center transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>

          {/* Modal Header */}
          <div className="flex items-center space-x-2.5 border-b border-slate-100 pb-3">
            <div className="w-9 h-9 bg-orange-100 text-orange-600 rounded-xl flex items-center justify-center">
              <Star className="w-4 h-4 fill-orange-500 text-orange-500" />
            </div>
            <div>
              <h2 className="text-base font-extrabold text-slate-900">Write a review</h2>
              <p className="text-[11px] text-slate-400">Share your experience with others</p>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-3.5">
            {/* Interactive Stars */}
            <div className="text-center py-2">
              <label className="text-xs font-bold text-slate-600 mb-2 block">Tap to rate</label>
              <div className="flex items-center justify-center gap-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onMouseEnter={() => setHoverRating(star)}
                    onMouseLeave={() => setHoverRating(null)}
                    onClick={() => setRating(star)}
                    className="p-1 text-slate-300 hover:scale-110 transition-transform cursor-pointer"
                  >
                    <Star
                      className={`w-7 h-7 ${
                        star <= currentDisplayRating
                          ? 'fill-amber-400 text-amber-400'
                          : 'text-slate-300 fill-slate-100'
                      }`}
                    />
                  </button>
                ))}
              </div>
              <span className="text-xs font-extrabold text-orange-600 mt-1 block">
                {currentDisplayRating}.0 / 5
              </span>
            </div>

            {/* Name */}
            <div>
              <label htmlFor="reviewNameInput" className="text-xs font-bold text-slate-700 mb-1 block">
                Your Name <span className="text-red-500">*</span>
              </label>
              <input
                id="reviewNameInput"
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Enter your full name"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs sm:text-sm focus:outline-hidden focus:border-orange-500 font-medium text-slate-800 transition"
              />
            </div>

            {/* Email */}
            <div>
              <label htmlFor="reviewEmailInput" className="text-xs font-bold text-slate-700 mb-1 block">
                Your Email <span className="text-red-500">*</span>
              </label>
              <input
                id="reviewEmailInput"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter your email address"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs sm:text-sm focus:outline-hidden focus:border-orange-500 font-medium text-slate-800 transition"
              />
            </div>

            {/* Description */}
            <div>
              <label htmlFor="reviewCommentInput" className="text-xs font-bold text-slate-700 mb-1 block">
                Review description <span className="text-red-500">*</span>
              </label>
              <textarea
                id="reviewCommentInput"
                rows={3}
                required
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                placeholder="What did you like or dislike about our service?"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs sm:text-sm focus:outline-hidden focus:border-orange-500 font-medium text-slate-800 transition resize-none"
              />
            </div>

            {/* Submit button */}
            <motion.button
              type="submit"
              disabled={isSubmitting}
              whileHover={{ scale: 1.01 }}
              whileTap={{ scale: 0.98 }}
              className="w-full bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 text-white font-extrabold py-3.5 rounded-xl text-xs sm:text-sm tracking-wider transition shadow-lg shadow-orange-500/20 flex items-center justify-center gap-2 disabled:opacity-70 cursor-pointer"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Submitting Review...</span>
                </>
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  <span>Post Review</span>
                </>
              )}
            </motion.button>
          </form>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
