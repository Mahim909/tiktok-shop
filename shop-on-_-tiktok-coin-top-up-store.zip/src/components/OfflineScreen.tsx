import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { WifiOff, RefreshCw, AlertTriangle, Smartphone, SignalHigh } from 'lucide-react';

interface OfflineScreenProps {
  onRetry: () => Promise<boolean>;
  isChecking: boolean;
}

export const OfflineScreen: React.FC<OfflineScreenProps> = ({ onRetry, isChecking }) => {
  const [retryFailed, setRetryFailed] = useState(false);

  const handleRetryClick = async () => {
    setRetryFailed(false);
    const connected = await onRetry();
    if (!connected) {
      setRetryFailed(true);
      setTimeout(() => setRetryFailed(false), 3000);
    }
  };

  return (
    <div className="fixed inset-0 z-[999] bg-slate-950/95 backdrop-blur-xl flex items-center justify-center p-4 selection:bg-orange-500 selection:text-white">
      <motion.div
        initial={{ opacity: 0, scale: 0.9, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
        className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl text-center relative overflow-hidden"
      >
        {/* Decorative background glow */}
        <div className="absolute -top-24 -left-24 w-48 h-48 bg-orange-600/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -right-24 w-48 h-48 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Animated Offline Icon */}
        <div className="relative mx-auto w-20 h-20 mb-6 flex items-center justify-center">
          <motion.div
            animate={{ scale: [1, 1.15, 1], opacity: [0.3, 0.7, 0.3] }}
            transition={{ duration: 2.5, repeat: Infinity, ease: "easeInOut" }}
            className="absolute inset-0 rounded-full bg-orange-500/20"
          />
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-orange-600 to-amber-500 flex items-center justify-center shadow-lg shadow-orange-500/25 text-white">
            <WifiOff className="w-8 h-8" />
          </div>
        </div>

        {/* Title & Description */}
        <div className="space-y-2 mb-6">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-orange-500/10 border border-orange-500/25 text-orange-400 text-xs font-semibold">
            <AlertTriangle className="w-3.5 h-3.5" />
            ইন্টারনেট সংযোগ প্রয়োজন
          </span>
          <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
            ইন্টারনেট ছাড়া অ্যাপটি চলবে না
          </h2>
          <p className="text-slate-400 text-xs sm:text-sm font-medium leading-relaxed">
            লাইভ TikTok কয়েন রেট, কুপন যাচাইকরণ ও নিরাপদ পেমেন্ট নিশ্চিত করতে একটি সচল ইন্টারনেট সংযোগ বাধ্যতামূলক।
          </p>
        </div>

        {/* Connection Tips */}
        <div className="bg-slate-800/60 border border-slate-700/60 rounded-2xl p-3.5 mb-6 text-left space-y-2 text-xs text-slate-300">
          <div className="flex items-center gap-2 text-slate-200 font-semibold text-[11px] uppercase tracking-wider">
            <SignalHigh className="w-3.5 h-3.5 text-orange-400" />
            দ্রুত চেক করে নিন:
          </div>
          <div className="flex items-start gap-2 text-slate-400 text-[11px]">
            <Smartphone className="w-3.5 h-3.5 shrink-0 mt-0.5 text-slate-400" />
            <span>আপনার মোবাইল ডাটা অথবা Wi-Fi চালু আছে কিনা নিশ্চিত করুন</span>
          </div>
          <div className="flex items-start gap-2 text-slate-400 text-[11px]">
            <span className="w-1.5 h-1.5 rounded-full bg-orange-500 shrink-0 mt-1.5 ml-1" />
            <span>ডিভাইসের Airplane Mode বন্ধ রাখুন এবং পুনরায় ট্রাই করুন</span>
          </div>
        </div>

        {/* Retry Button */}
        <button
          onClick={handleRetryClick}
          disabled={isChecking}
          className="w-full bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 active:scale-[0.98] text-white font-extrabold py-3.5 px-6 rounded-2xl text-xs sm:text-sm tracking-wide shadow-lg shadow-orange-500/25 flex items-center justify-center gap-2.5 transition-all duration-200 disabled:opacity-70 cursor-pointer"
        >
          <RefreshCw className={`w-4 h-4 ${isChecking ? 'animate-spin' : ''}`} />
          <span>{isChecking ? 'সংযোগ পরীক্ষা করা হচ্ছে...' : 'পুনরায় চেষ্টা করুন (Retry Connection)'}</span>
        </button>

        {/* Error notification if retry fails */}
        <AnimatePresence>
          {retryFailed && (
            <motion.p
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="text-xs text-red-400 font-semibold mt-3"
            >
              এখনও ইন্টারনেট সংযোগ নেই। দয়া করে আপনার নেটওয়ার্ক চেক করুন।
            </motion.p>
          )}
        </AnimatePresence>
      </motion.div>
    </div>
  );
};
