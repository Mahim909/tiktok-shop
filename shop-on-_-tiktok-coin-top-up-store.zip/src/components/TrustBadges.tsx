import React from 'react';
import { ShieldCheck, Lock, UserCheck, Headphones, Check } from 'lucide-react';

export const TrustBadges: React.FC = () => {
  const badges = [
    {
      title: 'SSL Encryption',
      subtext: '256-Bit Secure',
      icon: ShieldCheck,
      color: 'text-emerald-600 bg-emerald-50 border-emerald-100',
    },
    {
      title: 'Safe Payment',
      subtext: 'bKash, Nagad & Crypto',
      icon: Lock,
      color: 'text-blue-600 bg-blue-50 border-blue-100',
    },
    {
      title: 'Safe Account',
      subtext: 'Privacy Guaranteed',
      icon: UserCheck,
      color: 'text-purple-600 bg-purple-50 border-purple-100',
    },
    {
      title: '24/7 Protection',
      subtext: 'Instant Support',
      icon: Headphones,
      color: 'text-amber-600 bg-amber-50 border-amber-100',
    },
  ];

  return (
    <section className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4">
      {badges.map((b) => {
        const Icon = b.icon;
        return (
          <div
            key={b.title}
            className="bg-white border border-slate-200/80 p-3.5 sm:p-4 rounded-2xl flex items-center space-x-3 shadow-xs relative overflow-hidden group hover:border-slate-300 transition-colors"
          >
            {/* Verified badge top right */}
            <div className="absolute top-2.5 right-2.5 w-4 h-4 bg-emerald-500 rounded-full flex items-center justify-center text-white text-[9px] shadow-xs" title="Verified">
              <Check className="w-2.5 h-2.5 stroke-[3]" />
            </div>

            <div className={`w-10 h-10 sm:w-11 sm:h-11 rounded-xl flex items-center justify-center shrink-0 border ${b.color}`}>
              <Icon className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <p className="text-xs font-bold text-slate-900 truncate">{b.title}</p>
              <p className="text-[10px] text-slate-400 font-medium truncate">{b.subtext}</p>
            </div>
          </div>
        );
      })}
    </section>
  );
};
