import React from 'react';
import { motion } from 'motion/react';
import { CoinPackage } from '../types';
import { COIN_PACKAGES, COIN_RATE, USD_RATE } from '../data/constants';
import { TikTokCoinIcon } from './TikTokCoinIcon';
import { AlertCircle, Flame } from 'lucide-react';

interface CoinPackagesProps {
  selectedPackage: CoinPackage | null;
  onSelectPackage: (pkg: CoinPackage) => void;
  customCoins: string;
  onCustomCoinsChange: (val: string) => void;
  customCoinError: string | null;
}

export const CoinPackages: React.FC<CoinPackagesProps> = ({
  selectedPackage,
  onSelectPackage,
  customCoins,
  onCustomCoinsChange,
  customCoinError,
}) => {
  return (
    <div className="space-y-4">
      {/* Header and status badge */}
      <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
        <label className="text-xs font-extrabold text-slate-900 uppercase tracking-wider flex items-center gap-2">
          <span className="w-5 h-5 rounded-full bg-orange-500 text-white flex items-center justify-center text-[11px] font-bold">
            1
          </span>
          Select Coins Package
        </label>
        
        <span
          className={`text-[11px] font-bold px-2.5 py-1 rounded-lg border transition-all ${
            selectedPackage
              ? 'text-orange-700 bg-orange-100/90 border-orange-200'
              : 'text-slate-400 bg-slate-100 border-slate-200/60 italic'
          }`}
        >
          {selectedPackage ? `${selectedPackage.name} Selected` : 'Select a package or type below'}
        </span>
      </div>

      {/* Grid of Preset Packages */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2.5 sm:gap-3">
        {COIN_PACKAGES.map((pkg) => {
          const isSelected = selectedPackage?.id === pkg.id;
          const usdPrice = (pkg.price / USD_RATE).toFixed(2);

          return (
            <motion.button
              type="button"
              key={pkg.id}
              whileHover={{ y: -2 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => onSelectPackage(pkg)}
              className={`relative border rounded-2xl p-3 flex flex-col items-center text-center transition-all cursor-pointer ${
                isSelected
                  ? 'border-orange-500 bg-orange-50/80 shadow-md shadow-orange-500/10 ring-2 ring-orange-500/30'
                  : 'border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-50/50 shadow-2xs'
              }`}
            >
              {pkg.isPopular && (
                <span className="absolute -top-2 left-1/2 -translate-x-1/2 bg-gradient-to-r from-orange-500 to-amber-500 text-white text-[9px] font-black px-2 py-0.5 rounded-full shadow-2xs flex items-center gap-0.5 whitespace-nowrap">
                  <Flame className="w-2.5 h-2.5" /> HOT
                </span>
              )}

              <div className="w-10 h-10 rounded-full bg-amber-50/80 p-1 flex items-center justify-center mb-1.5 shadow-2xs border border-amber-200/60">
                <TikTokCoinIcon className="w-7 h-7" />
              </div>

              <span className="font-extrabold text-xs text-slate-800 tracking-tight">
                {pkg.name}
              </span>
              <span className="text-xs font-black text-orange-600 mt-0.5">
                ৳ {pkg.price.toLocaleString()}
              </span>
              <span className="text-[10px] font-semibold text-slate-400">
                (${usdPrice})
              </span>
            </motion.button>
          );
        })}
      </div>

      {/* Custom Coins Input Box */}
      <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200/80 relative mt-4">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-xl bg-amber-100/80 p-2 flex items-center justify-center shrink-0 border border-amber-200/80">
            <TikTokCoinIcon className="w-8 h-8" />
          </div>
          <div className="flex-1 min-w-0">
            <label
              htmlFor="customCoinField"
              className="text-[10px] font-extrabold uppercase text-slate-500 tracking-wider block mb-1"
            >
              Or Type Custom Coins (Min 100, Step 100, Rate: ৳{COIN_RATE}/coin)
            </label>
            <input
              id="customCoinField"
              type="number"
              min="100"
              max="1000000"
              step="100"
              value={customCoins}
              onChange={(e) => onCustomCoinsChange(e.target.value)}
              placeholder="e.g. 1500, 2500, 5000..."
              className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm font-black text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 transition shadow-2xs"
            />
          </div>
        </div>

        {customCoinError && (
          <motion.p
            initial={{ opacity: 0, y: -4 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-[11px] font-bold text-red-500 mt-2 flex items-center gap-1 pl-1"
          >
            <AlertCircle className="w-3.5 h-3.5 shrink-0" />
            <span>{customCoinError}</span>
          </motion.p>
        )}
      </div>
    </div>
  );
};
