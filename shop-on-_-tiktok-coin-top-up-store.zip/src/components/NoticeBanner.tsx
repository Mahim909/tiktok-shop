import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Bell, MessageSquareQuote, CheckCircle2 } from 'lucide-react';
import { Review } from '../types';

interface NoticeBannerProps {
  notice?: string;
}

export const NoticeBanner: React.FC<NoticeBannerProps> = ({
  notice = "অর্ডার করার ২-১০ মিনিটের মধ্যে কয়েন বা লাইভ গিফট পৌঁছে দেওয়া হবে!"
}) => {
  return (
    <div className="bg-gradient-to-r from-orange-500/10 via-amber-500/10 to-orange-500/5 border border-orange-200/80 rounded-2xl p-4 flex items-center justify-between shadow-2xs">
      <div className="flex items-center space-x-3">
        <span className="bg-gradient-to-r from-orange-500 to-amber-500 text-white text-[10px] px-3 py-1 rounded-lg font-black tracking-wider uppercase shadow-2xs shrink-0 flex items-center gap-1">
          <Bell className="w-3 h-3" />
          NOTICE
        </span>
        <p className="text-xs sm:text-sm text-slate-800 font-semibold leading-relaxed">
          {notice}
        </p>
      </div>
    </div>
  );
};

interface ReviewTickerProps {
  reviews: Review[];
}

export const ReviewTicker: React.FC<ReviewTickerProps> = ({ reviews }) => {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    if (!reviews || reviews.length === 0) return;
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % reviews.length);
    }, 4500);

    return () => clearInterval(interval);
  }, [reviews]);

  if (!reviews || reviews.length === 0) return null;

  const currentReview = reviews[currentIndex];

  return (
    <div className="bg-slate-900 text-white rounded-2xl p-3 px-4 flex items-center justify-between shadow-md border border-slate-800 overflow-hidden">
      <div className="flex items-center gap-3 overflow-hidden flex-1 min-w-0 pr-2">
        <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-orange-500 to-amber-500 text-white flex items-center justify-center text-xs shrink-0 shadow-sm">
          <MessageSquareQuote className="w-4 h-4" />
        </div>
        <div className="overflow-hidden min-w-0">
          <div className="flex items-center gap-1.5">
            <span className="text-[10px] text-orange-400 font-bold uppercase tracking-wider">
              Live Customer Feedback
            </span>
            <span className="text-slate-600">·</span>
            <span className="text-[10px] text-slate-400 font-medium truncate">
              {currentReview.name}
            </span>
          </div>
          <AnimatePresence mode="wait">
            <motion.p
              key={currentReview.id || currentIndex}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.3 }}
              className="text-xs font-medium text-slate-200 truncate mt-0.5"
            >
              "{currentReview.comment}"
            </motion.p>
          </AnimatePresence>
        </div>
      </div>
      <span className="text-[10px] bg-slate-800 text-slate-300 px-2.5 py-1 rounded-lg border border-slate-700 shrink-0 font-medium flex items-center gap-1">
        <CheckCircle2 className="w-3 h-3 text-emerald-400" />
        Verified
      </span>
    </div>
  );
};
