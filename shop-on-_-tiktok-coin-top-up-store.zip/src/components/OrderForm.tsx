import React from 'react';
import { motion } from 'motion/react';
import { CreditCard, Tag, Link2, AlertCircle, CheckCircle2, Loader2 } from 'lucide-react';
import { CoinPackage } from '../types';
import { USD_RATE } from '../data/constants';

interface OrderFormProps {
  selectedPackage: CoinPackage | null;
  videoUrl: string;
  onVideoUrlChange: (val: string) => void;
  urlError: string | null;
  couponCode: string;
  onCouponChange: (val: string) => void;
  isVerifyingCoupon: boolean;
  couponStatus: { type: 'success' | 'error' | null; message: string };
  discountAmount: number;
  appliedCouponName: string;
  onSubmitOrder: (e: React.FormEvent) => void;
}

export const OrderForm: React.FC<OrderFormProps> = ({
  selectedPackage,
  videoUrl,
  onVideoUrlChange,
  urlError,
  couponCode,
  onCouponChange,
  isVerifyingCoupon,
  couponStatus,
  discountAmount,
  appliedCouponName,
  onSubmitOrder,
}) => {
  const subtotal = selectedPackage ? selectedPackage.price : 0;
  const payable = Math.max(0, subtotal - discountAmount);

  const subtotalUsd = (subtotal / USD_RATE).toFixed(2);
  const discountUsd = (discountAmount / USD_RATE).toFixed(2);
  const payableUsd = (payable / USD_RATE).toFixed(2);

  return (
    <form onSubmit={onSubmitOrder} className="space-y-4 pt-4 border-t border-slate-100" noValidate>
      <label className="text-xs font-extrabold text-slate-900 uppercase tracking-wider block mb-1 flex items-center gap-2">
        <span className="w-5 h-5 rounded-full bg-orange-500 text-white flex items-center justify-center text-[11px] font-bold">
          2
        </span>
        TikTok Video Link & Coupon
      </label>

      {/* Video URL Input */}
      <div>
        <label htmlFor="videoUrlInput" className="text-xs font-bold text-slate-700 mb-1.5 flex items-center gap-1.5">
          <Link2 className="w-3.5 h-3.5 text-orange-500" />
          <span>Paste TikTok Video / Post / Profile URL</span>
          <span className="text-red-500">*</span>
        </label>
        <input
          id="videoUrlInput"
          type="url"
          value={videoUrl}
          onChange={(e) => onVideoUrlChange(e.target.value)}
          placeholder="https://vt.tiktok.com/... or https://tiktok.com/@username/video/..."
          className={`w-full bg-slate-50 border rounded-xl p-3 text-xs sm:text-sm font-medium text-slate-900 focus:outline-hidden focus:ring-2 transition shadow-2xs ${
            urlError
              ? 'border-red-400 focus:ring-red-500/20 focus:border-red-500'
              : 'border-slate-200 focus:ring-orange-500/20 focus:border-orange-500'
          }`}
        />
        {urlError && (
          <motion.p
            initial={{ opacity: 0, y: -4 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-[11px] font-bold text-red-500 mt-1.5 flex items-center gap-1"
          >
            <AlertCircle className="w-3.5 h-3.5 shrink-0" />
            <span>{urlError}</span>
          </motion.p>
        )}
      </div>

      {/* Coupon Code Section */}
      <div>
        <label htmlFor="couponInput" className="text-xs font-bold text-slate-700 mb-1.5 flex items-center gap-1.5">
          <Tag className="w-3.5 h-3.5 text-amber-500" />
          <span>Have a Coupon Code?</span>
        </label>
        <div className="relative">
          <input
            id="couponInput"
            type="text"
            value={couponCode}
            onChange={(e) => onCouponChange(e.target.value)}
            placeholder="Enter coupon code (e.g. DISCOUNT20, OFFER50, WELCOME)"
            className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 pr-10 text-xs sm:text-sm font-bold uppercase tracking-wide text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 transition shadow-2xs"
          />
          {isVerifyingCoupon && (
            <div className="absolute right-3 top-3.5 text-orange-500">
              <Loader2 className="w-4 h-4 animate-spin" />
            </div>
          )}
        </div>

        {couponStatus.type && (
          <motion.p
            initial={{ opacity: 0, y: -4 }}
            animate={{ opacity: 1, y: 0 }}
            className={`text-[11px] font-bold mt-1.5 flex items-center gap-1 ${
              couponStatus.type === 'success' ? 'text-emerald-600' : 'text-red-500'
            }`}
          >
            {couponStatus.type === 'success' ? (
              <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
            ) : (
              <AlertCircle className="w-3.5 h-3.5 shrink-0" />
            )}
            <span>{couponStatus.message}</span>
          </motion.p>
        )}
      </div>

      {/* Pricing Summary Box */}
      <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200/80 text-xs space-y-2 mt-4 shadow-2xs">
        <div className="flex justify-between items-center text-slate-600">
          <span>Package Price:</span>
          {selectedPackage ? (
            <span className="font-bold text-slate-800 tabular-nums">
              ৳ {subtotal.toLocaleString()} <span className="text-slate-400 font-normal">(${subtotalUsd})</span>
            </span>
          ) : (
            <span className="font-bold text-slate-400 italic">Waiting for selection...</span>
          )}
        </div>

        {discountAmount > 0 && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            className="flex justify-between items-center text-emerald-600 font-semibold"
          >
            <span>Discount ({appliedCouponName}):</span>
            <span className="font-bold tabular-nums">
              - ৳ {discountAmount.toFixed(2)} <span className="text-emerald-500/80 font-normal">(-${discountUsd})</span>
            </span>
          </motion.div>
        )}

        <div className="border-t border-slate-200/80 pt-2 flex justify-between items-center">
          <span className="font-black text-slate-900 text-sm">Payable Amount:</span>
          {selectedPackage ? (
            <span className="text-sm sm:text-base font-black text-emerald-600 tabular-nums">
              ৳ {payable.toLocaleString()} <span className="text-xs font-semibold text-emerald-700/80">(${payableUsd})</span>
            </span>
          ) : (
            <span className="text-sm font-bold text-slate-400 italic">Waiting for selection...</span>
          )}
        </div>
      </div>

      {/* Action Button */}
      <motion.button
        type="submit"
        whileHover={{ scale: 1.01 }}
        whileTap={{ scale: 0.98 }}
        className="w-full bg-gradient-to-r from-orange-500 via-amber-500 to-orange-500 hover:from-orange-600 hover:to-amber-600 active:from-orange-700 text-white font-extrabold py-3.5 sm:py-4 rounded-xl text-xs sm:text-sm tracking-wider transition shadow-lg shadow-orange-500/20 flex items-center justify-center gap-2 cursor-pointer"
      >
        <CreditCard className="w-4 h-4" />
        <span>
          PROCEED TO PAY (
          {selectedPackage ? `৳ ${payable.toLocaleString()}` : 'Waiting for selection...'}
          )
        </span>
      </motion.button>
    </form>
  );
};
