import { useState, useEffect, useCallback } from 'react';

export function useNetworkStatus() {
  const [isOnline, setIsOnline] = useState<boolean>(typeof navigator !== 'undefined' ? navigator.onLine : true);
  const [isChecking, setIsChecking] = useState<boolean>(false);

  const checkConnection = useCallback(async (): Promise<boolean> => {
    setIsChecking(true);
    if (!navigator.onLine) {
      setIsOnline(false);
      setIsChecking(false);
      return false;
    }

    try {
      // Ping check to verify true internet access
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 4000);
      
      const response = await fetch(`https://jsonplaceholder.typicode.com/todos/1?_t=${Date.now()}`, {
        method: 'HEAD',
        cache: 'no-store',
        mode: 'no-cors',
        signal: controller.signal,
      });
      clearTimeout(timeoutId);
      
      setIsOnline(true);
      setIsChecking(false);
      return true;
    } catch {
      // Even if specific ping target has CORS or is offline, test if navigator is online
      const onlineStatus = navigator.onLine;
      setIsOnline(onlineStatus);
      setIsChecking(false);
      return onlineStatus;
    }
  }, []);

  useEffect(() => {
    const handleOnline = () => {
      checkConnection();
    };

    const handleOffline = () => {
      setIsOnline(false);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Initial check on mount
    if (!navigator.onLine) {
      setIsOnline(false);
    }

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [checkConnection]);

  return { isOnline, isChecking, checkConnection };
}
