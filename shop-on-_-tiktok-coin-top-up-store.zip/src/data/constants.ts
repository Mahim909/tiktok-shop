import { CoinPackage, PaymentGateway, Review } from '../types';

export const FIREBASE_DB_URL = "https://angrybirdsclan-eb65f-default-rtdb.firebaseio.com/reviews.json";
export const COUPON_DB_URL = "https://free-fire-quize-default-rtdb.firebaseio.com/coupons.json";

export const USD_RATE = 115; // 1 USD = 115 BDT
export const COIN_RATE = 1.95; // 1 Coin = 1.95 BDT
export const WHATSAPP_NUMBER = "8801301492171";
export const SUPPORT_EMAIL = "support@shoponbd.work.gd";

// Generate fixed coin packages: 100 to 1000 in steps of 100
export const COIN_PACKAGES: CoinPackage[] = Array.from({ length: 10 }, (_, i) => {
  const coins = (i + 1) * 100;
  return {
    id: `coin-pkg-${coins}`,
    name: `${coins} Coins`,
    coins,
    price: Math.round(coins * COIN_RATE),
    isPopular: coins === 500 || coins === 1000,
  };
});

export const PAYMENT_GATEWAYS: Record<string, PaymentGateway> = {
  bkash: {
    id: 'bkash',
    name: 'bKash',
    label: 'bKash Personal Number:',
    numberOrAddress: '01321554192',
    instruction: 'Please Send Money to this Personal bKash Number:',
    trxPlaceholder: 'e.g. 9J87X7YY',
    logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT1oRAj4-AVSxUFCbd7HmWDXKu_Tbntq_u7QAaoI4RhRw&s=10'
  },
  nagad: {
    id: 'nagad',
    name: 'Nagad',
    label: 'Nagad Personal Number:',
    numberOrAddress: '01321554192',
    instruction: 'Please Send Money to this Personal Nagad Number:',
    trxPlaceholder: 'e.g. 7GA89M4X',
    logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR6jC9l2nr6R6J6_3oGXlxBI835qsRbpCN6fQlln-zyGA&s=10'
  },
  crypto: {
    id: 'crypto',
    name: 'USDT (TRC20)',
    label: 'USDT Address (TRC20):',
    numberOrAddress: 'TU5P4ptZVdbBSTsEpeQSfEH2yYiiS3GAcd',
    instruction: 'Please Send USDT (TRC20) to this Wallet Address:',
    trxPlaceholder: 'e.g. Transaction Hash / Order ID',
    logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR0fkc2r7tvPvZkOFF7Y3u01dVmYTmYkm9WnZVX4RyfyQ&s=10'
  }
};

// Fallback seed reviews in case network is slow or Firebase rtdb empty
export const SEED_REVIEWS: Review[] = [
  {
    id: 'seed-1',
    name: 'Tanvir Ahmed',
    email: 'tanvir@gmail.com',
    rating: 5,
    comment: 'Alhamdulillah matro 3 minute e 1000 coins peyechi! Service khub fast ar trusted.',
    timestamp: Date.now() - 1000 * 60 * 18,
  },
  {
    id: 'seed-2',
    name: 'MD Rakib Hasan',
    email: 'rakib@gmail.com',
    rating: 5,
    comment: 'Super fast TikTok coin top-up. bKash payment korar por WhatsApp e message dewar sathe sathe confirmation peyechi.',
    timestamp: Date.now() - 1000 * 60 * 55,
  },
  {
    id: 'seed-3',
    name: 'Shakil Khan',
    email: 'shakil@gmail.com',
    rating: 5,
    comment: 'Best TikTok coin shop in Bangladesh. Lowest rate 1.95tk per coin!',
    timestamp: Date.now() - 1000 * 60 * 120,
  },
  {
    id: 'seed-4',
    name: 'Sumona Akter',
    email: 'sumona@gmail.com',
    rating: 5,
    comment: 'Live stream e gift pathanor jonno emergency coin lagchilo, instant peyechi. Dhonnobad Shop-On team.',
    timestamp: Date.now() - 1000 * 60 * 240,
  },
  {
    id: 'seed-5',
    name: 'Fahim Morshed',
    email: 'fahim@gmail.com',
    rating: 4,
    comment: 'Valo service, safe and genuine coins. Shobai nite paren kono voy nei.',
    timestamp: Date.now() - 1000 * 60 * 400,
  }
];

// Fallback coupons
export const LOCAL_COUPONS: Record<string, number> = {
  'DISCOUNT20': 20,
  'SHOPON20': 20,
  'TIKTOK10': 10,
  'WELCOME': 15,
  'OFFER50': 50
};
