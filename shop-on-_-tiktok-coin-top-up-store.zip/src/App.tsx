import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useNetworkStatus } from './hooks/useNetworkStatus';
import { OfflineScreen } from './components/OfflineScreen';
import { Header } from './components/Header';
import { NoticeBanner, ReviewTicker } from './components/NoticeBanner';
import { TrustBadges } from './components/TrustBadges';
import { CoinPackages } from './components/CoinPackages';
import { OrderForm } from './components/OrderForm';
import { SupportSection } from './components/SupportSection';
import { ReviewsSection } from './components/ReviewsSection';
import { ReviewModal } from './components/ReviewModal';
import { PaymentModal } from './components/PaymentModal';
import { VerificationOverlay } from './components/VerificationOverlay';
import { Toast } from './components/Toast';
import { CoinPackage, PaymentGatewayId, Review } from './types';
import {
  COIN_PACKAGES,
  COIN_RATE,
  USD_RATE,
  WHATSAPP_NUMBER,
  FIREBASE_DB_URL,
  COUPON_DB_URL,
  SEED_REVIEWS,
  LOCAL_COUPONS,
} from './data/constants';

export default function App() {
  // Network connectivity status (internet chara app open hobena)
  const { isOnline, isChecking, checkConnection } = useNetworkStatus();

  // Selection states
  const [selectedPackage, setSelectedPackage] = useState<CoinPackage | null>(null);
  const [customCoins, setCustomCoins] = useState<string>('');
  const [customCoinError, setCustomCoinError] = useState<string | null>(null);

  // Order form states
  const [videoUrl, setVideoUrl] = useState<string>('');
  const [urlError, setUrlError] = useState<string | null>(null);

  // Coupon states
  const [couponCode, setCouponCode] = useState<string>('');
  const [isVerifyingCoupon, setIsVerifyingCoupon] = useState<boolean>(false);
  const [couponStatus, setCouponStatus] = useState<{
    type: 'success' | 'error' | null;
    message: string;
  }>({ type: null, message: '' });
  const [discountAmount, setDiscountAmount] = useState<number>(0);
  const [appliedCouponName, setAppliedCouponName] = useState<string>('');
  const couponDebounceRef = useRef<NodeJS.Timeout | null>(null);

  // Payment Modal & Gateway states
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState<boolean>(false);
  const [selectedGateway, setSelectedGateway] = useState<PaymentGatewayId>('bkash');
  const [trxId, setTrxId] = useState<string>('');
  const [trxError, setTrxError] = useState<string | null>(null);

  // Security Verification simulation overlay states
  const [isVerificationOpen, setIsVerificationOpen] = useState<boolean>(false);
  const [verificationProgress, setVerificationProgress] = useState<number>(0);
  const [verificationStepText, setVerificationStepText] = useState<string>(
    'Connecting to Secure Gateway...'
  );

  // Reviews & modal
  const [reviews, setReviews] = useState<Review[]>(SEED_REVIEWS);
  const [isLoadingReviews, setIsLoadingReviews] = useState<boolean>(true);
  const [isReviewModalOpen, setIsReviewModalOpen] = useState<boolean>(false);
  const [isSubmittingReview, setIsSubmittingReview] = useState<boolean>(false);

  // Toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [toastType, setToastType] = useState<'success' | 'error'>('success');

  const showToast = useCallback((msg: string, type: 'success' | 'error' = 'success') => {
    setToastMessage(msg);
    setToastType(type);
    setTimeout(() => {
      setToastMessage(null);
    }, 2800);
  }, []);

  // Fetch reviews from Firebase Realtime DB
  const fetchReviews = useCallback(async () => {
    try {
      setIsLoadingReviews(true);
      const res = await fetch(FIREBASE_DB_URL);
      if (res.ok) {
        const data = await res.json();
        if (data && typeof data === 'object') {
          const loaded: Review[] = Object.keys(data)
            .map((key) => ({
              id: key,
              name: data[key].name || 'User',
              email: data[key].email || '',
              rating: Number(data[key].rating) || 5,
              comment: data[key].comment || '',
              timestamp: data[key].timestamp || Date.now(),
            }))
            .reverse();
          setReviews(loaded);
          return;
        }
      }
      // If empty or non-200, keep seed reviews
      setReviews(SEED_REVIEWS);
    } catch {
      // In case of network error, gracefully use seed reviews
      setReviews(SEED_REVIEWS);
    } finally {
      setIsLoadingReviews(false);
    }
  }, []);

  useEffect(() => {
    if (isOnline) {
      fetchReviews();
    }
  }, [isOnline, fetchReviews]);

  // Handle Preset Package selection
  const handleSelectPackage = (pkg: CoinPackage) => {
    setSelectedPackage(pkg);
    setCustomCoins('');
    setCustomCoinError(null);
  };

  // Handle Custom Coins input
  const handleCustomCoinsChange = (val: string) => {
    setCustomCoins(val);
    const count = parseInt(val, 10) || 0;

    if (!val) {
      setCustomCoinError(null);
      setSelectedPackage(null);
      return;
    }

    if (count < 100 || count % 100 !== 0 || count > 1000000) {
      setCustomCoinError('Minimum 100 coins required in increments of 100 (e.g. 100, 200, 300).');
      setSelectedPackage(null);
      return;
    }

    setCustomCoinError(null);
    const calculatedPrice = Math.round(count * COIN_RATE);
    setSelectedPackage({
      id: `custom-${count}`,
      name: `${count.toLocaleString()} Custom Coins`,
      coins: count,
      price: calculatedPrice,
    });
  };

  // Debounced Coupon auto verification
  const handleCouponChange = (val: string) => {
    setCouponCode(val);
    const code = val.trim().toUpperCase();

    if (couponDebounceRef.current) {
      clearTimeout(couponDebounceRef.current);
    }

    if (!code) {
      setIsVerifyingCoupon(false);
      setCouponStatus({ type: null, message: '' });
      setDiscountAmount(0);
      setAppliedCouponName('');
      return;
    }

    setIsVerifyingCoupon(true);
    setCouponStatus({ type: null, message: '' });

    couponDebounceRef.current = setTimeout(async () => {
      try {
        let discountFound = 0;

        // Check external database
        try {
          const res = await fetch(COUPON_DB_URL);
          if (res.ok) {
            const dbCoupons = await res.json();
            if (dbCoupons && typeof dbCoupons === 'object') {
              for (const k in dbCoupons) {
                const item = dbCoupons[k];
                if (
                  k.toUpperCase() === code ||
                  (item && item.code && item.code.toUpperCase() === code)
                ) {
                  const val = parseFloat(item.discount || item.amount || 0);
                  if (val > 0) {
                    discountFound = val;
                    break;
                  }
                }
              }
            }
          }
        } catch {
          // continue to local fallback
        }

        // Check local fallback coupons
        if (discountFound === 0 && LOCAL_COUPONS[code]) {
          discountFound = LOCAL_COUPONS[code];
        }

        setIsVerifyingCoupon(false);

        if (discountFound > 0) {
          setDiscountAmount(discountFound);
          setAppliedCouponName(code);
          setCouponStatus({
            type: 'success',
            message: `Coupon applied successfully! (-৳${discountFound})`,
          });
          showToast(`Coupon "${code}" applied (-৳${discountFound})`);
        } else {
          setDiscountAmount(0);
          setAppliedCouponName('');
          setCouponStatus({
            type: 'error',
            message: 'Invalid or expired coupon code',
          });
        }
      } catch {
        setIsVerifyingCoupon(false);
        setCouponStatus({
          type: 'error',
          message: 'Error verifying coupon. Please try again.',
        });
      }
    }, 500);
  };

  // Handle Proceed to Pay
  const handleProceedToPay = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPackage) {
      showToast('Please select a package or enter custom coins first!', 'error');
      return;
    }

    const trimmedUrl = videoUrl.trim();
    if (!trimmedUrl) {
      setUrlError('Please enter your TikTok video or profile URL!');
      return;
    }

    if (
      !trimmedUrl.includes('tiktok.com') &&
      !trimmedUrl.startsWith('http://') &&
      !trimmedUrl.startsWith('https://')
    ) {
      setUrlError('Please provide a valid TikTok URL (e.g. https://vt.tiktok.com/...)');
      return;
    }

    setUrlError(null);
    setIsPaymentModalOpen(true);
  };

  // Confirm order & trigger verification progress + WhatsApp redirect
  const handleConfirmPayment = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanTrx = trxId.trim();

    if (!cleanTrx) {
      setTrxError('Please enter Transaction ID (TrxID)');
      return;
    }

    setTrxError(null);
    setIsPaymentModalOpen(false);
    setIsVerificationOpen(true);
    setVerificationProgress(0);
    setVerificationStepText('Connecting to Secure Payment Gateway...');

    let progress = 0;
    const interval = setInterval(() => {
      progress += 5;
      setVerificationProgress(progress);

      if (progress === 40) {
        setVerificationStepText('Processing Payment Details...');
      } else if (progress === 80) {
        setVerificationStepText('Redirecting to WhatsApp Order Desk...');
      }

      if (progress >= 100) {
        clearInterval(interval);

        const pkgName = selectedPackage ? selectedPackage.name : 'TikTok Coins';
        const subtotal = selectedPackage ? selectedPackage.price : 0;
        const finalTotal = Math.max(0, subtotal - discountAmount);
        const totalUsd = (finalTotal / USD_RATE).toFixed(2);

        const gatewayLabel =
          selectedGateway === 'crypto' ? 'USDT / Crypto (TRC20)' : selectedGateway.toUpperCase();
        const idLabel = selectedGateway === 'crypto' ? 'TxID / Order ID' : 'TrxID';

        let message = `*NEW TIKTOK COIN ORDER FROM SHOP-ON*%0A%0A` +
          `🛒 *Item:* TIKTOK COIN TOP-UP%0A` +
          `💎 *Package:* ${pkgName}%0A` +
          `💵 *Subtotal:* ৳ ${subtotal}%0A`;

        if (discountAmount > 0) {
          message += `🎟️ *Coupon Applied:* ${appliedCouponName} (-৳ ${discountAmount})%0A`;
        }

        message +=
          `💰 *Total Paid:* ৳ ${finalTotal} ($${totalUsd})%0A` +
          `💳 *Payment Method:* ${gatewayLabel}%0A` +
          `🔗 *Video URL:* ${encodeURIComponent(videoUrl.trim())}%0A` +
          `💳 *${idLabel}:* ${encodeURIComponent(cleanTrx)}`;

        setTimeout(() => {
          setIsVerificationOpen(false);
          // Clean form
          setTrxId('');
          // Redirect to WhatsApp
          window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${message}`, '_blank');
        }, 350);
      }
    }, 70);
  };

  // Submit review to Firebase Realtime DB
  const handleSubmitReview = async (newRev: {
    name: string;
    email: string;
    rating: number;
    comment: string;
  }) => {
    setIsSubmittingReview(true);
    const reviewData = {
      ...newRev,
      timestamp: Date.now(),
    };

    try {
      const res = await fetch(FIREBASE_DB_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(reviewData),
      });

      if (res.ok) {
        showToast('Review submitted successfully!');
        setIsReviewModalOpen(false);
        // Refresh reviews
        fetchReviews();
      } else {
        // Optimistic local add
        setReviews((prev) => [{ id: `local-${Date.now()}`, ...reviewData }, ...prev]);
        showToast('Review posted successfully!');
        setIsReviewModalOpen(false);
      }
    } catch {
      // Optimistic local add on network limitation
      setReviews((prev) => [{ id: `local-${Date.now()}`, ...reviewData }, ...prev]);
      showToast('Review posted successfully!');
      setIsReviewModalOpen(false);
    } finally {
      setIsSubmittingReview(false);
    }
  };

  const payableAmount = selectedPackage ? Math.max(0, selectedPackage.price - discountAmount) : 0;

  return (
    <div className="bg-slate-50 text-slate-800 min-h-screen pb-16 selection:bg-orange-500 selection:text-white relative">
      {/* Strict Network Offline Blocker (internet chara app open hobena) */}
      {!isOnline && (
        <OfflineScreen onRetry={checkConnection} isChecking={isChecking} />
      )}

      {/* Toast Notification */}
      <Toast message={toastMessage} type={toastType} />

      {/* Header */}
      <Header />

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 mt-6 space-y-6">
        {/* Notice Banner */}
        <NoticeBanner />

        {/* Live Customer Feedback Ticker */}
        <ReviewTicker reviews={reviews} />

        {/* Trust Badges */}
        <TrustBadges />

        {/* Top-up Selection & Order Section */}
        <section className="bg-white border border-slate-200/80 rounded-3xl p-5 sm:p-7 shadow-xs space-y-6">
          {/* Section Heading */}
          <div className="flex items-center space-x-3.5 border-b border-slate-100 pb-4">
            <div className="w-12 h-12 bg-slate-900 rounded-2xl flex items-center justify-center text-amber-400 text-2xl shadow-md shrink-0">
              <svg className="w-6 h-6 fill-current" viewBox="0 0 24 24">
                <path d="M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72.02 1.48-.04 2.96-.04 4.44-.99-.32-2.15-.23-3.02.37-.63.41-1.11 1.04-1.36 1.75-.21.51-.24 1.07-.14 1.61.24 1.64 1.82 3.02 3.5 2.87 1.12-.01 2.19-.66 2.77-1.61.19-.33.4-.67.41-1.06.1-1.79.06-3.57.07-5.36.01-4.03-.01-8.05.02-12.07z" />
              </svg>
            </div>
            <div>
              <h1 className="text-lg sm:text-xl font-black text-slate-900 tracking-wide uppercase">
                TikTok Coins Top-Up
              </h1>
              <p className="text-xs text-slate-500 font-medium">
                Select package or type custom coins, paste link & confirm
              </p>
            </div>
          </div>

          {/* Step 1: Packages */}
          <CoinPackages
            selectedPackage={selectedPackage}
            onSelectPackage={handleSelectPackage}
            customCoins={customCoins}
            onCustomCoinsChange={handleCustomCoinsChange}
            customCoinError={customCoinError}
          />

          {/* Step 2: Order Form */}
          <OrderForm
            selectedPackage={selectedPackage}
            videoUrl={videoUrl}
            onVideoUrlChange={(val) => {
              setVideoUrl(val);
              if (urlError) setUrlError(null);
            }}
            urlError={urlError}
            couponCode={couponCode}
            onCouponChange={handleCouponChange}
            isVerifyingCoupon={isVerifyingCoupon}
            couponStatus={couponStatus}
            discountAmount={discountAmount}
            appliedCouponName={appliedCouponName}
            onSubmitOrder={handleProceedToPay}
          />
        </section>

        {/* Support Section */}
        <SupportSection />

        {/* Ratings and Reviews Section */}
        <ReviewsSection
          reviews={reviews}
          isLoading={isLoadingReviews}
          onOpenReviewModal={() => setIsReviewModalOpen(true)}
        />
      </main>

      {/* Payment Gateway Modal */}
      <PaymentModal
        isOpen={isPaymentModalOpen}
        onClose={() => setIsPaymentModalOpen(false)}
        payableAmount={payableAmount}
        selectedGateway={selectedGateway}
        onSelectGateway={setSelectedGateway}
        trxId={trxId}
        onTrxIdChange={(val) => {
          setTrxId(val);
          if (trxError) setTrxError(null);
        }}
        trxError={trxError}
        onConfirmPayment={handleConfirmPayment}
        onShowToast={showToast}
      />

      {/* Security Verification Simulation Overlay */}
      <VerificationOverlay
        isOpen={isVerificationOpen}
        progress={verificationProgress}
        stepText={verificationStepText}
      />

      {/* Write a Review Modal */}
      <ReviewModal
        isOpen={isReviewModalOpen}
        onClose={() => setIsReviewModalOpen(false)}
        onSubmit={handleSubmitReview}
        isSubmitting={isSubmittingReview}
      />
    </div>
  );
}
